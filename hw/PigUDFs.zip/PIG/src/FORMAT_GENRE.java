import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.pig.EvalFunc;
import org.apache.pig.data.Tuple;
import org.apache.pig.impl.util.WrappedIOException;

public class FORMAT_GENRE extends EvalFunc <String>{

	@Override
	public String exec(Tuple input) throws IOException {
		// TODO Auto-generated method stub
		if (input == null || input.size() == 0)
            return null;
        try{
            String str = (String)input.get(0);
            
            String outStr = "";
	    	StringTokenizer strArr = new StringTokenizer(str.toString().trim(),"|");
	    	
	    	int len = strArr.countTokens();
	    	
	    	if(len>=2)
	    	{
	    		for(int i=0;i<len-1;i++)
		    	{
		    		outStr = outStr + strArr.nextToken() + ", ";
		    	}
	    		outStr = outStr + "and " + strArr.nextToken();
	    	}
	    	else
	    	{
	    		outStr = str;
	    	}
	    	return outStr;
	    	
//            return str.replace("|", ", ");
        }catch(Exception e){
            throw WrappedIOException.wrap("Caught exception processing input row ", e);
        }
	}

}
